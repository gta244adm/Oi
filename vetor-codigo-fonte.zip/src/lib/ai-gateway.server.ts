import { createOpenAI } from "@ai-sdk/openai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

const LOVABLE_AIG_RUN_ID_HEADER = "X-Lovable-AIG-Run-ID";

export function createLovableAiGatewayRunIdFetch(initialRunId?: string) {
  let runId = initialRunId?.trim() || undefined;
  let resolveRunId: (value: string | undefined) => void = () => {};
  let runIdResolved = false;
  const runIdReady = new Promise<string | undefined>((resolve) => {
    resolveRunId = resolve;
  });

  const publishRunId = (value?: string) => {
    const nextRunId = value?.trim() || undefined;
    if (!runId && nextRunId) runId = nextRunId;
    if (!runIdResolved) {
      runIdResolved = true;
      resolveRunId(runId);
    }
  };
  if (runId) publishRunId(runId);

  return {
    fetch: (async (input: RequestInfo | URL, init?: RequestInit) => {
      const headers = new Headers(init?.headers);
      if (runId && !headers.has(LOVABLE_AIG_RUN_ID_HEADER)) {
        headers.set(LOVABLE_AIG_RUN_ID_HEADER, runId);
      }
      try {
        const response = await fetch(input, { ...init, headers });
        publishRunId(response.headers.get(LOVABLE_AIG_RUN_ID_HEADER) ?? undefined);
        return response;
      } catch (error) {
        publishRunId(undefined);
        throw error;
      }
    }) as typeof fetch,
    getRunId: () => runId,
    waitForRunId: () => (runId ? Promise.resolve(runId) : runIdReady),
  };
}

export function getLovableAiGatewayRunId(request: Request) {
  return request.headers.get(LOVABLE_AIG_RUN_ID_HEADER)?.trim() || undefined;
}

/** Responses-API provider for `openai/*` gateway models. */
export function createLovableResponsesProvider(apiKey: string, initialRunId?: string) {
  const runIdFetch = createLovableAiGatewayRunIdFetch(initialRunId);
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: {
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    fetch: runIdFetch.fetch,
  });
  return { provider, runIdFetch };
}

/** Chat-completions provider for gateway models that are not `openai/*`. */
export function createLovableChatProvider(apiKey: string, initialRunId?: string) {
  const runIdFetch = createLovableAiGatewayRunIdFetch(initialRunId);
  const provider = createOpenAICompatible({
    name: "lovable",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: {
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    fetch: runIdFetch.fetch,
  });
  return { provider, runIdFetch };
}

/** Direct provider using the app owner's own OpenAI key. */
export function createDirectOpenAiProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "openai-direto",
    baseURL: "https://api.openai.com/v1",
    apiKey,
  });
}

/** Direct provider using the app owner's own Google AI Studio key. */
export function createDirectGoogleProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "google-direto",
    baseURL: "https://generativelanguage.googleapis.com/v1beta/openai",
    apiKey,
  });
}

export type SourceStatus =
  | { state: "ok" }
  | { state: "blocked"; status: number; message: string }
  | { state: "down"; message: string };

const statusCache = new Map<string, { at: number; value: SourceStatus }>();

function cached(key: string): SourceStatus | undefined {
  const hit = statusCache.get(key);
  if (!hit) return undefined;
  const ttl = hit.value.state === "ok" ? 60_000 : 30_000;
  if (Date.now() - hit.at > ttl) return undefined;
  return hit.value;
}

function remember(key: string, value: SourceStatus): SourceStatus {
  statusCache.set(key, { at: Date.now(), value });
  return value;
}

function describe(status: number, source: "gateway" | "openai" | "google"): SourceStatus {
  if (status === 402) {
    return {
      state: "blocked",
      status,
      message:
        source === "gateway"
          ? "Os créditos de IA da Lovable acabaram."
          : "A conta do provedor de IA está sem saldo.",
    };
  }
  if (status === 401 || status === 403) {
    return {
      state: "blocked",
      status,
      message:
        source === "gateway"
          ? "O uso da IA está bloqueado nas configurações do workspace."
          : "A chave de IA configurada foi recusada (inválida ou sem permissão).",
    };
  }
  return { state: "down", message: `Serviço indisponível no momento (${status}).` };
}

/** Cheap availability probe: 1 token, so credit/permission problems surface before streaming. */
export async function probeGateway(apiKey: string): Promise<SourceStatus> {
  const hit = cached("gateway");
  if (hit) return hit;
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "google/gemini-3.1-flash-lite",
        messages: [{ role: "user", content: "ping" }],
        max_tokens: 1,
      }),
    });
    if (res.ok) return remember("gateway", { state: "ok" });
    return remember("gateway", describe(res.status, "gateway"));
  } catch (error) {
    return remember("gateway", {
      state: "down",
      message: error instanceof Error ? error.message : "Falha de rede.",
    });
  }
}

/** Free key check against the provider's model listing. */
export async function probeDirect(
  source: "openai" | "google",
  apiKey: string,
): Promise<SourceStatus> {
  const hit = cached(source);
  if (hit) return hit;
  const url =
    source === "openai"
      ? "https://api.openai.com/v1/models"
      : `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
  try {
    const res = await fetch(url, {
      headers: source === "openai" ? { Authorization: `Bearer ${apiKey}` } : {},
    });
    if (res.ok) return remember(source, { state: "ok" });
    return remember(source, describe(res.status, source));
  } catch (error) {
    return remember(source, {
      state: "down",
      message: error instanceof Error ? error.message : "Falha de rede.",
    });
  }
}

export type GatewayImage = { base64: string; mimeType: string };

/** Generate an image through the Lovable AI Gateway image endpoint. */
export async function generateGatewayImage(
  apiKey: string,
  prompt: string,
): Promise<GatewayImage> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: "google/gemini-3-pro-image",
      prompt,
      n: 1,
    }),
  });

  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`Falha ao gerar imagem (${res.status}): ${detail.slice(0, 300)}`);
  }

  const json = (await res.json()) as {
    data?: Array<{ b64_json?: string; url?: string; mime_type?: string }>;
  };
  const first = json.data?.[0];
  if (!first) throw new Error("O serviço de imagens não retornou nenhuma imagem.");

  if (first.b64_json) {
    return { base64: first.b64_json, mimeType: first.mime_type ?? "image/png" };
  }
  if (first.url) {
    const imgRes = await fetch(first.url);
    const buf = new Uint8Array(await imgRes.arrayBuffer());
    let binary = "";
    for (let i = 0; i < buf.length; i += 1) binary += String.fromCharCode(buf[i]!);
    return {
      base64: btoa(binary),
      mimeType: imgRes.headers.get("content-type") ?? "image/png",
    };
  }
  throw new Error("Formato de imagem não reconhecido.");
}
