import type { UIMessage } from "ai";

import { supabase } from "@/integrations/supabase/client";

export type Thread = {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
};

export const SIGNED_URL_TTL = 60 * 60 * 24 * 365;

export async function listThreads(): Promise<Thread[]> {
  const { data, error } = await supabase
    .from("threads")
    .select("id, title, created_at, updated_at")
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Thread[];
}

export async function createThread(title = "Nova conversa"): Promise<Thread> {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id;
  if (!userId) throw new Error("Você precisa entrar para conversar.");

  const { data, error } = await supabase
    .from("threads")
    .insert({ title, user_id: userId })
    .select("id, title, created_at, updated_at")
    .single();
  if (error) throw error;
  return data as Thread;
}

export async function renameThread(id: string, title: string) {
  const { error } = await supabase.from("threads").update({ title }).eq("id", id);
  if (error) throw error;
}

export async function deleteThread(id: string) {
  const { error } = await supabase.from("threads").delete().eq("id", id);
  if (error) throw error;
}

export async function loadMessages(threadId: string): Promise<UIMessage[]> {
  const { data, error } = await supabase
    .from("messages")
    .select("id, client_id, role, parts, created_at")
    .eq("thread_id", threadId)
    .order("created_at", { ascending: true });
  if (error) throw error;

  return (data ?? []).map((row) => ({
    id: (row.client_id as string) || (row.id as string),
    role: row.role as UIMessage["role"],
    parts: (row.parts ?? []) as UIMessage["parts"],
  }));
}

export type UploadedFile = {
  type: "file";
  mediaType: string;
  filename: string;
  url: string;
};

export async function uploadAttachment(file: File): Promise<UploadedFile> {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id;
  if (!userId) throw new Error("Você precisa entrar para enviar arquivos.");

  const safeName = file.name.replace(/[^\w.\-]+/g, "_").slice(-80);
  const path = `${userId}/enviados/${crypto.randomUUID()}-${safeName}`;

  const { error } = await supabase.storage
    .from("chat-files")
    .upload(path, file, { contentType: file.type || "application/octet-stream" });
  if (error) throw error;

  const { data: signed, error: signedError } = await supabase.storage
    .from("chat-files")
    .createSignedUrl(path, SIGNED_URL_TTL);
  if (signedError) throw signedError;

  return {
    type: "file",
    mediaType: file.type || "application/octet-stream",
    filename: file.name,
    url: signed.signedUrl,
  };
}

const PENDING_KEY = "vetor:pending";

export type PendingMessage = { threadId: string; text: string; files: UploadedFile[] };

export function setPendingMessage(pending: PendingMessage) {
  sessionStorage.setItem(PENDING_KEY, JSON.stringify(pending));
}

export function takePendingMessage(threadId: string): PendingMessage | null {
  if (typeof window === "undefined") return null;
  const raw = sessionStorage.getItem(PENDING_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as PendingMessage;
    if (parsed.threadId !== threadId) return null;
    sessionStorage.removeItem(PENDING_KEY);
    return parsed;
  } catch {
    sessionStorage.removeItem(PENDING_KEY);
    return null;
  }
}
