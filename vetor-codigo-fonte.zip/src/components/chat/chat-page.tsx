import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

import { ChatWorkspace } from "@/components/chat/chat-workspace";
import { useAuth } from "@/hooks/use-auth";

export function ChatPage({ threadId }: { threadId?: string | undefined }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth", replace: true });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="size-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return <ChatWorkspace threadId={threadId} userEmail={user.email ?? null} />;
}
