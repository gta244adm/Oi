import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LogOut, MessageSquarePlus, Search, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { deleteThread, listThreads } from "@/lib/chat-data";
import { cn } from "@/lib/utils";

function groupLabel(iso: string) {
  const date = new Date(iso);
  const now = new Date();
  const days = Math.floor((now.getTime() - date.getTime()) / 86_400_000);
  if (days < 1) return "Hoje";
  if (days < 2) return "Ontem";
  if (days < 7) return "Últimos 7 dias";
  if (days < 30) return "Últimos 30 dias";
  return "Mais antigas";
}

export function ThreadSidebar({
  activeThreadId,
  userEmail,
  onNavigate,
}: {
  activeThreadId?: string | undefined;
  userEmail?: string | null | undefined;
  onNavigate?: (() => void) | undefined;
}) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const queryClient = useQueryClient();


  const { data: threads = [], isLoading } = useQuery({
    queryKey: ["threads"],
    queryFn: listThreads,
  });

  const removeThread = useMutation({
    mutationFn: deleteThread,
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["threads"] });
      if (id === activeThreadId) navigate({ to: "/" });
    },
    onError: () => toast.error("Não foi possível apagar a conversa."),
  });

  const groups = useMemo(() => {
    const filtered = threads.filter((thread) =>
      thread.title.toLowerCase().includes(query.trim().toLowerCase()),
    );
    const map = new Map<string, typeof filtered>();
    for (const thread of filtered) {
      const label = groupLabel(thread.updated_at);
      map.set(label, [...(map.get(label) ?? []), thread]);
    }
    return [...map.entries()];
  }, [threads, query]);

  return (
    <aside className="flex h-full w-full shrink-0 flex-col border-border bg-sidebar md:w-72 md:border-r">
      <div className="flex items-center gap-2 px-4 py-4">
        <div className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
          <span className="font-mono text-sm font-bold">V</span>
        </div>
        <div className="leading-tight">
          <p className="text-sm font-semibold text-foreground">Vetor</p>
          <p className="text-[11px] text-muted-foreground">Chat com IA</p>
        </div>
      </div>

      <div className="space-y-2 px-3">
        <Button asChild className="w-full justify-start gap-2">
          <Link to="/" onClick={onNavigate}>
            <MessageSquarePlus className="size-4" />
            Nova conversa
          </Link>
        </Button>

        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar conversas"
            className="h-9 pl-8 text-sm"
          />
        </div>
      </div>

      <nav className="mt-3 flex-1 overflow-y-auto px-2 pb-4">
        {isLoading ? (
          <div className="space-y-2 px-1 py-2">
            {[0, 1, 2, 3].map((index) => (
              <div key={index} className="h-8 w-full rounded-md bg-muted/40" />
            ))}
          </div>
        ) : groups.length === 0 ? (
          <p className="px-3 py-6 text-xs text-muted-foreground">
            Nenhuma conversa ainda.
          </p>
        ) : (
          groups.map(([label, items]) => (
            <div key={label} className="mb-3">
              <p className="px-3 py-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                {label}
              </p>
              <ul className="space-y-0.5">
                {items.map((thread) => (
                  <li key={thread.id} className="group/item relative">
                    <Link
                      to="/c/$threadId"
                      params={{ threadId: thread.id }}
                      onClick={onNavigate}
                      className={cn(
                        "block truncate rounded-md px-3 py-2.5 pr-10 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground md:py-2",
                        thread.id === activeThreadId &&
                          "bg-accent text-foreground",
                      )}
                    >
                      {thread.title}
                    </Link>
                    <button
                      type="button"
                      aria-label={`Apagar ${thread.title}`}
                      onClick={() => removeThread.mutate(thread.id)}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground opacity-70 transition-colors hover:bg-destructive/15 hover:text-destructive md:opacity-0 md:group-hover/item:opacity-100"
                    >
                      <Trash2 className="size-3.5" />
                    </button>

                  </li>
                ))}
              </ul>
            </div>
          ))
        )}
      </nav>

      <div className="border-t border-border px-3 py-3">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-xs text-muted-foreground">{userEmail}</p>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Sair"
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/auth" });
            }}
          >
            <LogOut className="size-4" />
          </Button>
        </div>
      </div>
    </aside>
  );
}
