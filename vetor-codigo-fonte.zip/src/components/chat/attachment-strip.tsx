import { Paperclip, X } from "lucide-react";

import { usePromptInputAttachments } from "@/components/ai-elements/prompt-input";

export function AttachmentStrip() {
  const attachments = usePromptInputAttachments();
  if (attachments.files.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2 px-3 pt-3">
      {attachments.files.map((file) => (
        <div
          key={file.id}
          className="relative flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-2 py-1.5 text-xs text-foreground"
        >
          {file.mediaType?.startsWith("image/") && file.url ? (
            <img
              src={file.url}
              alt={file.filename ?? "Anexo"}
              className="size-8 rounded object-cover"
            />
          ) : (
            <Paperclip className="size-4 text-muted-foreground" />
          )}
          <span className="max-w-[10rem] truncate">{file.filename ?? "Arquivo"}</span>
          <button
            type="button"
            aria-label="Remover anexo"
            onClick={() => attachments.remove(file.id)}
            className="rounded p-0.5 text-muted-foreground hover:bg-destructive/15 hover:text-destructive"
          >
            <X className="size-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}
