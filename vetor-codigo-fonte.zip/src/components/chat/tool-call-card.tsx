import type { UIMessage } from "ai";
import { Globe, ImageIcon } from "lucide-react";

import {
  Tool,
  ToolContent,
  ToolHeader,
  ToolInput,
  ToolOutput,
  type ToolPart,
} from "@/components/ai-elements/tool";

type SearchResult = { titulo: string; url: string; resumo: string };

function isSearchOutput(
  output: unknown,
): output is { consulta: string; resultados: SearchResult[] } {
  return (
    typeof output === "object" &&
    output !== null &&
    Array.isArray((output as { resultados?: unknown }).resultados)
  );
}

function isImageOutput(output: unknown): output is { url: string; prompt: string } {
  return (
    typeof output === "object" &&
    output !== null &&
    typeof (output as { url?: unknown }).url === "string"
  );
}

export function ToolCallCard({ part }: { part: UIMessage["parts"][number] }) {
  const toolPart = part as ToolPart;
  const name = toolPart.type.replace("tool-", "");
  const isImage = name === "gerar_imagem";
  const output = "output" in toolPart ? toolPart.output : undefined;
  const errorText = "errorText" in toolPart ? toolPart.errorText : undefined;

  if (isImage && toolPart.state === "output-available" && isImageOutput(output)) {
    return (
      <figure className="mb-3">
        <img
          src={output.url}
          alt={output.prompt}
          className="max-h-[28rem] w-full rounded-xl border border-border object-contain"
        />
        <figcaption className="mt-1.5 text-xs text-muted-foreground">
          Imagem gerada · {output.prompt}
        </figcaption>
      </figure>
    );
  }

  if (!isImage && toolPart.state === "output-available" && isSearchOutput(output)) {
    return (
      <div className="mb-3 rounded-xl border border-border bg-card p-3">
        <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <Globe className="size-3.5" />
          Resultados da web · {output.consulta}
        </p>
        <ul className="space-y-2">
          {output.resultados.map((result) => (
            <li key={result.url}>
              <a
                href={result.url}
                target="_blank"
                rel="noreferrer"
                className="block rounded-lg px-2 py-1.5 transition-colors hover:bg-accent"
              >
                <p className="truncate text-sm font-medium text-foreground">
                  {result.titulo}
                </p>
                <p className="line-clamp-2 text-xs text-muted-foreground">
                  {result.resumo}
                </p>
              </a>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <Tool defaultOpen={false} className="mb-3">
      <ToolHeader
        type={toolPart.type as `tool-${string}`}
        state={toolPart.state}
        title={isImage ? "Gerando imagem" : "Buscando na web"}
      />
      <ToolContent>
        <ToolInput input={"input" in toolPart ? toolPart.input : undefined} />
        <ToolOutput
          output={
            isImage && isImageOutput(output) ? (
              <img src={output.url} alt={output.prompt} className="rounded-lg" />
            ) : output ? (
              <pre className="overflow-x-auto text-xs">
                {JSON.stringify(output, null, 2)}
              </pre>
            ) : null
          }
          errorText={errorText}
        />
      </ToolContent>
      <span className="sr-only">
        <ImageIcon className="size-0" />
      </span>
    </Tool>
  );
}
