import { useChat } from "@ai-sdk/react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { DefaultChatTransport, type FileUIPart, type UIMessage } from "ai";
import {
  Globe,
  ImageIcon,
  Menu,
  MessageSquarePlus,
  Paperclip,
  Sparkle,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";


import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputActionAddAttachments,
  PromptInputActionMenu,
  PromptInputActionMenuContent,
  PromptInputActionMenuTrigger,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
  type PromptInputMessage,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { AttachmentStrip } from "@/components/chat/attachment-strip";
import { ThreadSidebar } from "@/components/chat/thread-sidebar";
import { ToolCallCard } from "@/components/chat/tool-call-card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import {
  createThread,
  loadMessages,
  setPendingMessage,
  takePendingMessage,
  uploadAttachment,
  type UploadedFile,
} from "@/lib/chat-data";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Explique computação quântica como se eu tivesse 12 anos",
  "Gere uma imagem de um farol ao amanhecer, estilo aquarela",
  "Busque as notícias mais recentes sobre inteligência artificial",
  "Reescreva este texto num tom mais profissional",
];

async function toUploadedFiles(files: FileUIPart[]): Promise<UploadedFile[]> {
  const uploaded: UploadedFile[] = [];
  for (const part of files) {
    const response = await fetch(part.url);
    const blob = await response.blob();
    const file = new File([blob], part.filename ?? "arquivo", {
      type: part.mediaType || blob.type,
    });
    uploaded.push(await uploadAttachment(file));
  }
  return uploaded;
}

export function ChatWorkspace({
  threadId,
  userEmail,
}: {
  threadId?: string | undefined;
  userEmail?: string | null | undefined;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);


  const { data: initialMessages } = useQuery({
    queryKey: ["messages", threadId],
    queryFn: () => (threadId ? loadMessages(threadId) : Promise.resolve([])),
    enabled: Boolean(threadId),
  });

  const { messages, sendMessage, status, error, stop } = useChat({
    id: threadId ?? "novo",
    messages: (initialMessages ?? []) as UIMessage[],
    transport: new DefaultChatTransport({
      api: "/api/chat",
      body: { threadId },
      headers: async () => {
        const { data } = await supabase.auth.getSession();
        const token = data.session?.access_token;
        return token ? { Authorization: `Bearer ${token}` } : {};
      },
    }),
    onFinish: () => {
      queryClient.invalidateQueries({ queryKey: ["threads"] });
    },
    onError: (chatError) => {
      toast.error(chatError.message || "Algo deu errado ao falar com a IA.");
    },
  });

  const busy = status === "submitted" || status === "streaming";

  const focusComposer = useCallback(() => {
    // Em telas pequenas, não abrir o teclado automaticamente.
    if (typeof window !== "undefined" && window.innerWidth < 768) return;
    requestAnimationFrame(() => textareaRef.current?.focus());
  }, []);


  useEffect(() => {
    focusComposer();
  }, [threadId, focusComposer]);

  useEffect(() => {
    if (!busy) focusComposer();
  }, [busy, focusComposer]);

  const send = useCallback(
    (text: string, files: UploadedFile[]) => {
      void sendMessage({
        text,
        files: files.map((file) => ({
          type: "file" as const,
          mediaType: file.mediaType,
          filename: file.filename,
          url: file.url,
        })),
      });
    },
    [sendMessage],
  );

  // Auto-send the message typed on the home screen after the thread is created.
  const pendingHandled = useRef(false);
  useEffect(() => {
    if (!threadId || pendingHandled.current) return;
    const pending = takePendingMessage(threadId);
    if (!pending) return;
    pendingHandled.current = true;
    send(pending.text, pending.files);
  }, [threadId, send]);

  const handleSubmit = async (message: PromptInputMessage) => {
    const text = message.text.trim();
    if (!text && message.files.length === 0) return;
    if (busy) return;

    try {
      setUploading(true);
      const uploaded = await toUploadedFiles(message.files);

      if (!threadId) {
        const thread = await createThread(text.slice(0, 60) || "Nova conversa");
        setPendingMessage({ threadId: thread.id, text, files: uploaded });
        await queryClient.invalidateQueries({ queryKey: ["threads"] });
        navigate({ to: "/c/$threadId", params: { threadId: thread.id } });
        return;
      }

      send(text, uploaded);
    } catch (submitError) {
      toast.error(
        submitError instanceof Error
          ? submitError.message
          : "Não foi possível enviar sua mensagem.",
      );
    } finally {
      setUploading(false);
    }
  };

  const showEmptyState = !threadId && messages.length === 0;

  return (
    <div className="flex h-[100dvh] bg-background">
      <div className="hidden md:flex">
        <ThreadSidebar activeThreadId={threadId} userEmail={userEmail} />
      </div>

      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="left" className="w-[86vw] max-w-xs p-0">
          <SheetTitle className="sr-only">Conversas</SheetTitle>
          <ThreadSidebar
            activeThreadId={threadId}
            userEmail={userEmail}
            onNavigate={() => setMenuOpen(false)}
          />
        </SheetContent>
      </Sheet>

      <main className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-border px-2 py-2 md:hidden">
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            aria-label="Abrir conversas"
            onClick={() => setMenuOpen(true)}
          >
            <Menu className="size-5" />
          </Button>
          <p className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
            Vetor
          </p>
          <Button
            asChild
            variant="ghost"
            size="icon-sm"
            aria-label="Nova conversa"
          >
            <Link to="/">
              <MessageSquarePlus className="size-5" />
            </Link>
          </Button>
        </header>

        <Conversation className="flex-1">
          <ConversationContent className="mx-auto w-full max-w-3xl px-3 pb-4 pt-5 sm:px-4 sm:pt-8">
            {showEmptyState ? (
              <div className="flex min-h-[45vh] flex-col items-center justify-center text-center sm:min-h-[55vh]">

                <div className="mb-5 flex size-14 items-center justify-center rounded-2xl bg-primary/15 text-primary">
                  <Sparkle className="size-6" />
                </div>
                <h1 className="text-2xl font-semibold text-foreground">
                  Como posso ajudar hoje?
                </h1>
                <p className="mt-2 max-w-md text-sm text-muted-foreground">
                  Converse, envie arquivos e fotos, peça imagens novas ou busque
                  informações atuais na web.
                </p>
                <div className="mt-7 grid w-full max-w-2xl gap-2 sm:grid-cols-2">
                  {SUGGESTIONS.map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => handleSubmit({ text: suggestion, files: [] })}
                      className="rounded-xl border border-border bg-card px-4 py-3 text-left text-sm text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <Message key={message.id} from={message.role} className="msg-in">
                  <MessageContent
                    className={cn(
                      message.role === "assistant" &&
                        "bg-transparent p-0 text-foreground",
                    )}
                  >
                    {message.parts.map((part, index) => {
                      const key = `${message.id}-${index}`;

                      if (part.type === "text") {
                        return (
                          <MessageResponse key={key}>{part.text}</MessageResponse>
                        );
                      }

                      if (part.type === "reasoning" && part.text) {
                        return (
                          <details
                            key={key}
                            className="mb-3 rounded-lg border border-border bg-muted/30 px-3 py-2 text-xs text-muted-foreground"
                          >
                            <summary className="cursor-pointer select-none">
                              Raciocínio
                            </summary>
                            <p className="mt-2 whitespace-pre-wrap">{part.text}</p>
                          </details>
                        );
                      }

                      if (part.type === "file") {
                        return part.mediaType?.startsWith("image/") ? (
                          <img
                            key={key}
                            src={part.url}
                            alt={part.filename ?? "Imagem enviada"}
                            className="mb-2 max-h-80 rounded-xl border border-border object-cover"
                          />
                        ) : (
                          <a
                            key={key}
                            href={part.url}
                            target="_blank"
                            rel="noreferrer"
                            className="mb-2 flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm text-foreground"
                          >
                            <Paperclip className="size-4 text-muted-foreground" />
                            {part.filename ?? "Arquivo"}
                          </a>
                        );
                      }

                      if (part.type.startsWith("tool-")) {
                        return <ToolCallCard key={key} part={part} />;
                      }

                      return null;
                    })}
                  </MessageContent>
                </Message>
              ))
            )}

            {status === "submitted" ? (
              <Shimmer className="px-1 text-sm">Pensando...</Shimmer>
            ) : null}

            {error ? (
              <p className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error.message}
              </p>
            ) : null}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>

        <div className="border-t border-border bg-background/80 px-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur sm:px-4 sm:py-4">
          <div className="mx-auto w-full max-w-3xl">
            <PromptInput
              onSubmit={handleSubmit}
              accept="image/*,application/pdf,text/*"
              multiple
              maxFiles={5}
              maxFileSize={25 * 1024 * 1024}
              onError={(err) => toast.error(err.message)}
            >
              <AttachmentStrip />
              <PromptInputTextarea
                ref={textareaRef}
                placeholder="Pergunte qualquer coisa ao Vetor..."
              />
              <PromptInputFooter>
                <PromptInputTools>
                  <PromptInputActionMenu>
                    <PromptInputActionMenuTrigger />
                    <PromptInputActionMenuContent>
                      <PromptInputActionAddAttachments label="Enviar arquivo ou foto" />
                    </PromptInputActionMenuContent>
                  </PromptInputActionMenu>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-muted-foreground"
                    onClick={() => {
                      const el = textareaRef.current;
                      if (!el) return;
                      el.value = `Busque na web: ${el.value}`;
                      el.dispatchEvent(new Event("input", { bubbles: true }));
                      el.focus();
                    }}
                  >
                    <Globe className="size-4" />
                    <span className="hidden sm:inline">Web</span>
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-muted-foreground"
                    onClick={() => {
                      const el = textareaRef.current;
                      if (!el) return;
                      el.value = `Gere uma imagem de ${el.value}`;
                      el.dispatchEvent(new Event("input", { bubbles: true }));
                      el.focus();
                    }}
                  >
                    <ImageIcon className="size-4" />
                    <span className="hidden sm:inline">Imagem</span>
                  </Button>
                </PromptInputTools>
                <PromptInputSubmit
                  status={uploading ? "submitted" : status}
                  disabled={uploading}
                  onClick={busy ? () => stop() : undefined}
                />
              </PromptInputFooter>
            </PromptInput>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              O Vetor pode cometer erros. Confira informações importantes.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
