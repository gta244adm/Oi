# Terminar o Vetor (chat com IA)

Retomando exatamente de onde paramos. Já estão prontos: banco de dados (conversas, mensagens, perfis com acesso por usuário), armazenamento privado de arquivos, o visual escuro "Esmeralda escuro", a conversa com a IA no servidor (com busca na web, geração de imagens e leitura de arquivos), a barra lateral e a tela principal do chat.

## O que falta

1. **Tela de entrada** (`/auth`): criar conta e entrar com e‑mail e senha, além de entrar com o Google. Mensagens de erro claras em português e redirecionamento para o chat após entrar.
2. **Página inicial**: substituir a tela em branco padrão pelo chat. Quem não estiver logado é levado para a tela de entrada.
3. **Página de cada conversa** (`/c/...`): abre a conversa escolhida na barra lateral, com o histórico salvo.
4. **Sair da conta**: botão na barra lateral que limpa a sessão e volta para a tela de entrada.
5. **Ajustes finais**: corrigir os detalhes de tipos nos anexos do campo de mensagem e nas ferramentas, garantindo que a prévia abra sem erros.
6. **Teste de ponta a ponta**: entrar, criar conversa, enviar texto, enviar uma foto, pedir uma imagem e fazer uma busca na web — conferindo que o histórico persiste ao recarregar.

## Detalhes técnicos

- Rotas novas: `src/routes/auth.tsx` (pública), `src/routes/_authenticated/route.tsx` (portão de sessão gerenciado, `ssr: false`, redireciona para `/auth`), `src/routes/_authenticated/c.$threadId.tsx`.
- `src/routes/index.tsx` passa a renderizar o chat sem conversa selecionada; como o portão de rota não pode coexistir com o índice na mesma pasta, o índice verifica a sessão no cliente e redireciona para `/auth` quando não houver usuário.
- Google: chamar `lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin })` e habilitar o provedor Google no backend no mesmo passo.
- Sair: cancelar consultas em andamento, limpar cache, `supabase.auth.signOut()` e navegar para `/auth` com `replace`.
- Metadados próprios (título, descrição, og/twitter) em cada página de conteúdo.
- Sem mudanças no banco de dados; a chave de IA e o bucket privado já estão configurados.
