# Vetor: uso sem travas + correção do erro vermelho

## Sobre o "uso infinito"

Não existe IA gratuita e infinita: cada resposta é paga por alguém. Hoje o app usa os créditos de IA da Lovable, e o saldo do seu espaço está quase no fim (4 de 5 créditos do dia, bônus zerado). Por isso o chat mostra erro vermelho.

Você escolheu "os dois", então o app vai funcionar assim:

1. Tenta responder com os créditos da Lovable (como hoje).
2. Se acabarem os créditos, o acesso estiver bloqueado ou o serviço falhar, ele passa automaticamente para a **sua própria chave** (OpenAI ou Google), sem você perceber.
3. Se nenhuma das duas estiver disponível, aparece uma mensagem clara em português dizendo exatamente o que fazer.

Com a sua chave configurada, o limite passa a ser o do seu plano no provedor — na prática, uso contínuo sem depender dos créditos da Lovable.

## O erro vermelho

O que já está confirmado: nenhuma chamada de IA saiu do app nas últimas 24 horas e o saldo de créditos está no fim — ou seja, o pedido está sendo recusado antes de a IA responder.

O que ainda não está confirmado é se o texto vermelho vem só da falta de créditos ou se há também uma falha na troca automática de modelo. Hoje essa troca é feita de um jeito que não funciona de verdade: o app espera um sinal que quase nunca acusa falha, então a conversa pode simplesmente morrer em silêncio ou devolver um erro cru. Por isso o primeiro passo é reproduzir o erro e ler a resposta real do servidor antes de mexer em mais nada.

## Passos

1. Reproduzir o envio de uma mensagem e capturar o erro exato (código e texto) que chega na tela.
2. Refazer a troca automática de modelo para que ela realmente detecte a falha e tente a próxima opção, em vez de depender do sinal atual.
3. Adicionar a sua chave própria como segunda fonte, usada automaticamente quando a primeira falha.
4. Deixar as mensagens de erro amigáveis: sem créditos, chave inválida, limite do provedor, serviço fora do ar — cada uma com o que fazer.
5. Testar no celular (360x569) e no computador: enviar texto, anexar foto, gerar imagem e buscar na web.

## O que vou pedir a você

Uma chave de API sua — OpenAI (`sk-...`) ou Google AI Studio. Vou abrir um campo seguro para você colar; a chave fica guardada criptografada e nunca aparece no chat nem no código.

## Detalhes técnicos

- `src/routes/api/chat.ts`: substituir o laço que aguarda `candidate.warnings` por uma seleção que consuma o início do stream (ou capture o erro do primeiro chunk) antes de responder, tratando 402/403 como terminais e 429/5xx com nova tentativa no próximo modelo.
- `src/lib/ai-gateway.server.ts`: adicionar um provedor alternativo que usa a chave do usuário (`OPENAI_API_KEY` ou `GOOGLE_GENERATIVE_AI_API_KEY`) apontando direto para o provedor, mantendo o mesmo formato de stream e as mesmas ferramentas.
- Cadeia final: `openai/gpt-6-astra` (gateway) → modelos Gemini do gateway → provedor direto com a chave do usuário.
- Geração de imagem (`generateGatewayImage`) recebe o mesmo tratamento de erro; se o gateway recusar, a ferramenta devolve mensagem clara em vez de quebrar a resposta.
- Nenhum timeout artificial nas chamadas; erros continuam sendo mostrados na interface, nunca escondidos atrás de uma resposta genérica.
